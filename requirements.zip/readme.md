# Submission Proyek Analisis Data

## Setup Project

```bash
# Clone repository
git clone
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
streamlit run dashboard/dashboard.py
```
